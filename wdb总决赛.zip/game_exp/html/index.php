<?php
require_once "login_requre.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>打字游戏</title>
    <link rel="stylesheet" href="index.css">
</head>

<body>
    <button id="setting-btn" type="button" class="setting-btn">
        <i class="fas fa-cog"></i>
    </button>
    <div id="setting" class="setting">
        <form>
            <div>
                <label>游戏难易程度:</label>
                <div class="select-container select-hard">
                    <div class="select-title">
                        <div class="select-content" tabindex="0" hidefocus="true"></div>
                        <i class="select-icon select-down"></i>
                    </div>
                    <ul class="select-items"></ul>
                </div>
            </div>
        </form>

        <label style="margin-left: 200px">您的总分为:  <span id="u_score" style="color: red"></span> <span style="display: none">(听说分数达到1000分可解锁隐藏任务???)</span></label>

    </div>

    <div class="container">
        <h2>👩‍💻 速度打字机 👨‍💻</h2>
        <small>键入如下的单词:</small>
        <h1 id="word">juice</h1>
        <input type="text" class="text" id="text" placeholder="请输入示例单词">
        <p class="time-container">
            剩余时间:
            <span id="time">0s</span>
        </p>
        <p class="score-container">
            得分:
            <span id="score">0分</span>
        </p>
    </div>
</body>
<script src="plugins/popbox.js"></script>
<script src="plugins/message.js"></script>
<script src="index.js"></script>
<script>
    function updateUserScore(){
        var url = "score.php"
        var xhr = new XMLHttpRequest()
        xhr.open("GET",url,true);
        xhr.withCredentials = true;
        xhr.send(null);
        xhr.onreadystatechange = function () {
            if(xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                var obj = JSON.parse(xhr.responseText);
                var  u_score = document.getElementById("u_score")
                if (obj.status === "success"){
                    u_score.innerText = obj.score
                }
            }
        }
    }
    setInterval('updateUserScore();', 1000);

</script>
</html>