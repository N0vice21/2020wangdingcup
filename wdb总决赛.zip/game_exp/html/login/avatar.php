<?php
if (isset($_GET['username'])) {
    include_once "../sqlhelper.php";
    $username = addslashes($_GET['username']);
    $mysql = new sqlhelper();
    $sql = "SELECT avatar FROM user where username = '$username'";
    $res = $mysql->execute_dql($sql);
    $resp = [];
    if ($res) {
        $row = $res->fetch_row();
        if ($row) {
            $resp['status'] = "success";
            $resp['img'] = $row[0];
            echo json_encode($resp);
            exit(1);
        }
    }
    $resp['status'] = "fail";
    $resp['img'] = "";
    echo json_encode($resp);
}
