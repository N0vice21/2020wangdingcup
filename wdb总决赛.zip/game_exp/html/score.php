<?php
include_once "sqlhelper.php";

require_once "login_requre.php";

if (isset($_GET['score'])) {

    $score = intval($_GET['score']);
    $mysql = new sqlhelper();
    $username = addslashes($_SESSION['username']);
    $sql = "UPDATE user SET score=score+$score WHERE username = '$username'";
    $res = $mysql->execute_dml($sql);
    $resp = [];
    $resp['status'] = "fail";

    if ($res) {
        $resp['status'] = "success";

    }
    echo json_encode($resp);
}else{
    $mysql = new sqlhelper();
    $username = addslashes($_SESSION['username']);
    $sql = "SELECT score FROM user where username = '$username'";
    $res = $mysql->execute_dql($sql);
    $row = $res->fetch_row();
    $resp = [];
    $resp['status'] = "fail";
    if ($res) {
        $resp['status'] = "success";
        $resp['score'] = $row[0];

    }
    echo json_encode($resp);

}

