<?php
include_once "sqlhelper.php";

class Goder
{

    public $uid;

    public function recordOrNot()
    {
        $mysql = new sqlhelper();
        $uid = addslashes($this->uid);
        $sql = "SELECT score FROM user where id = '$uid'";
        $res = $mysql->execute_dql($sql);
        $row = $res->fetch_row();
        if ($res) {
            if ($row[0] > 1000) {
                $sql = "INSERT INTO goder ( uid ) VALUES ('$uid')";
                $res = $mysql->execute_dml($sql);
            }
        }
    }

}

class User
{
    public $uid;
    public $goder_text;

    public function __construct($uid)
    {
        $this->uid = $uid;
        $goder = new Goder();
        $goder->uid = $uid;
        $this->goder_text = serialize($goder);

    }

    public function __destruct()
    {
        $goder = unserialize($this->goder_text);
        $goder->recordOrNot();
    }


}

