CREATE DATABASE IF NOT EXISTS games DEFAULT CHARSET utf8 COLLATE utf8_general_ci;

use games;

create table user
(
    id       int auto_increment
        primary key,
    username char(100)     not null,
    password char(100)     null,
    avatar   char(100)     null,
    score    int default 0 null
);

create table goder
(
    id  int auto_increment
        primary key,
    uid int not null,
    constraint goder_uid_uindex
        unique (uid)
);

