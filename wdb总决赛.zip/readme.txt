reset脚本在比赛中用于清除服务异常状态，备份用于学习
————README written by N0vice