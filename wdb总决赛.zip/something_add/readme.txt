确实是个core
文件路径：/home/ctf/pwn