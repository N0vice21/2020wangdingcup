其他可能有用的信息：
war包路径：
/usr/tomcat/apache-tomcat-8.5.35/webapps/ROOT.war
Web根目录：
/usr/tomcat/apache-tomcat-8.5.35/webapps/ROOT/

Other information that may be useful:
The path of war:
/usr/tomcat/apache-tomcat-8.5.35/webapps/ROOT.war
The Web root path:
/usr/tomcat/apache-tomcat-8.5.35/webapps/ROOT/

