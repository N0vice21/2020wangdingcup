该目录下的文件，对应在远程主机上的目录为 /source ,
例如：该目录下 app.js 在远程主机上的绝对路径为 /source/app.js .

The files in this directory correspond to the directory on the remote host as /source ,
For example: the absolute path of app.js in this directory on the remote host is /source/app.js .

