#!/bin/bash
cd /source && npm start
tail -F /dev/null

