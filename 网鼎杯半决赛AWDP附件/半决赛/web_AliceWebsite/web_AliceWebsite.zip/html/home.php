<?php
echo "
        <div class='jumbotron'>
            <h1>Here is Alice's Website!</h1>
            <p>Because it has not been developed yet, there are only a few functions.</p>
            <p><a class='btn btn-primary btn-lg' href='index.php?action=about.php' role='button'>About Me</a></p>
        </div>
";