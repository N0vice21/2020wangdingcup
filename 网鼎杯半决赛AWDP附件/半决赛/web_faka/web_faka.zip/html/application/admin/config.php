<?php
return [
    "SESSION_END"=>"60000",
    "AUTO_UPDATE_INSTALL_FILE" => "/tmp/qianbao.zip",
];