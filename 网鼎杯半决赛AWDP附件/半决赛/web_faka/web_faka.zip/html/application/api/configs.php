<?php

return [
    'ios_crypt_key' => '8df1b74cfa009913',
    'android_crypt_key' => '4ce19ca8fcd150a4',
    'web_crypt_key' => '9705eb7ac2c98403',
    'wxapp_crypt_key' => '90a5732cf34e7e55',
];