<?php
/**
 * 通用部署变量配置文件，请将此文件在发布平台中设置为"配置文件"
 */
return [
    'version_list_url' => 'http://local.piplin.cn/api/project/get_available_list',
    'version_update_url' => 'http://local.piplin.cn/deploy',
];